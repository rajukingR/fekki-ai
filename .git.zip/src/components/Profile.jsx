import React, { useState } from "react";
import {
  Box,
  Button,
  Typography,
  FormGroup,
  FormControlLabel,
  Checkbox,
  TextField,
} from "@mui/material";
import { useNavigate } from "react-router-dom";

const options = [
  { id: "ar", label: "Augmented Reality (AR)" },
  { id: "vr", label: "Virtual Reality (VR)" },
];

const goals = [
  { id: "assembly", label: "Assembly Guidance" },
  { id: "troubleshooting", label: "Troubleshooting Assistance" },
  { id: "training", label: "Operational Training" },
];

const platforms = [
  { id: "mobile", label: "Mobile devices" },
  { id: "glasses", label: "Smart glasses" },
  { id: "vr_headsets", label: "VR headsets" },
  { id: "desktop", label: "Desktop application" },
  { id: "web", label: "Web-based experience" },
];

const ImmersiveTechSelection = () => {
  const [step, setStep] = useState(1);
  const [selectedOptions, setSelectedOptions] = useState([]);
  const [productDetails, setProductDetails] = useState("");
  const [selectedGoals, setSelectedGoals] = useState([]);
  const [requirements, setRequirements] = useState("");
  const [selectedPlatforms, setSelectedPlatforms] = useState([]);
  const [compliance, setCompliance] = useState("");
  const navigate = useNavigate();

  const handleCheckboxChange = (id, stateUpdater) => {
    stateUpdater((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleNext = () => {
    if (step < 6) setStep(step + 1);
    else navigate("/next-page");
  };

  const handleBack = () => {
    if (step > 1) setStep(step - 1);
  };

  return (
    <Box sx={{ minHeight: "100vh", p: 4, textAlign: "center" }}>
      <Typography variant="h5" fontWeight="bold" sx={{ color: "white" }}>
        Superside + Rohith’s Team
      </Typography>

      <Box
        sx={{
          mt: 3,
          background: "white",
          textAlign: "left",
          maxWidth: 600,
          mx: "auto",
          p: 3,
          borderRadius: 2,
          boxShadow: 2,
          border: "1px solid black",
        }}
      >
        <Box sx={{ backgroundColor: "white", color: "black", p: 2, borderRadius: 2, mb: 2 }}>
          <Typography variant="h4" fontWeight="bold" sx={{ fontStyle: "italic" }}>
            {step === 1 && "What type of immersive technology solution are you interested in?"}
            {step === 2 && "Which product(s) or manual(s) would you like to enhance?"}
            {step === 3 && "What is the primary goal of your immersive solution?"}
            {step === 4 && "Do you have specific requirements in mind?"}
            {step === 5 && "What is your preferred platform?"}
            {step === 6 && "Are there any compliance requirements?"}
          </Typography>
        </Box>

        {step === 1 && (
          <FormGroup>
            {options.map((option) => (
              <FormControlLabel
                key={option.id}
                control={
                  <Checkbox
                    checked={selectedOptions.includes(option.id)}
                    onChange={() => handleCheckboxChange(option.id, setSelectedOptions)}
                    sx={{ color: "black" }}
                  />
                }
                label={<Typography sx={{ color: "black" }}>{option.label}</Typography>}
              />
            ))}
          </FormGroup>
        )}

        {step === 2 && (
          <TextField
            fullWidth
            variant="outlined"
            placeholder="Enter product details..."
            value={productDetails}
            onChange={(e) => setProductDetails(e.target.value)}
          />
        )}

        {step === 3 && (
          <FormGroup>
            {goals.map((goal) => (
              <FormControlLabel
                key={goal.id}
                control={
                  <Checkbox
                    checked={selectedGoals.includes(goal.id)}
                    onChange={() => handleCheckboxChange(goal.id, setSelectedGoals)}
                    sx={{ color: "black" }}
                  />
                }
                label={<Typography sx={{ color: "black" }}>{goal.label}</Typography>}
              />
            ))}
          </FormGroup>
        )}

        {step === 4 && (
          <TextField
            fullWidth
            variant="outlined"
            placeholder="Enter requirements..."
            value={requirements}
            onChange={(e) => setRequirements(e.target.value)}
          />
        )}

        {step === 5 && (
          <FormGroup>
            {platforms.map((platform) => (
              <FormControlLabel
                key={platform.id}
                control={
                  <Checkbox
                    checked={selectedPlatforms.includes(platform.id)}
                    onChange={() => handleCheckboxChange(platform.id, setSelectedPlatforms)}
                    sx={{ color: "black" }}
                  />
                }
                label={<Typography sx={{ color: "black" }}>{platform.label}</Typography>}
              />
            ))}
          </FormGroup>
        )}

        {step === 6 && (
          <TextField
            fullWidth
            variant="outlined"
            placeholder="Specify compliance requirements..."
            value={compliance}
            onChange={(e) => setCompliance(e.target.value)}
          />
        )}
      </Box>

      {/* Buttons */}
      <Box sx={{ mt: 4, display: "flex", justifyContent: "space-between", maxWidth: 600, mx: "auto" }}>
        <Button
          variant="contained"
          onClick={handleBack}
          sx={{ backgroundColor: "gray", color: "white", textTransform: "none", fontWeight: "bold" }}
          disabled={step === 1}
        >
          Back
        </Button>

        <Button
          variant="contained"
          onClick={handleNext}
          sx={{ backgroundColor: "#B7FF6A", color: "#0E1C11", textTransform: "none", fontWeight: "bold" }}
        >
          {step < 6 ? "Continue" : "Submit"}
        </Button>
      </Box>
    </Box>
  );
};

export default ImmersiveTechSelection;